This resource pack is an extension of the original New Default+ resource pack. It is heavily recommended
that you use this resource pack alongside the main New Default+ pack. If you haven't downloaded it yet,
you can find it here: https://minecraft.curseforge.com/projects/newdefaultplus

After installing both of these resource packs, make sure you order the two packs in-game in the resource
packs list so that the PvP pack is *above* the original New Default+ pack. Enjoy!


~SeaOfPixels